<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9c470fb8de8d621fefce60e1309d066d',
      'native_key' => 'personalize',
      'filename' => 'modNamespace/33c64dcdc192ef023a6346a1f8aa8811.vehicle',
      'namespace' => 'personalize',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cf058ddf946d8db8a017819b74c71b82',
      'native_key' => 1,
      'filename' => 'modCategory/9ac14b18629f617a8beb033d68288edd.vehicle',
      'namespace' => 'personalize',
    ),
  ),
);